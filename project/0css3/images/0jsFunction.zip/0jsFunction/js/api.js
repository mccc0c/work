$(function() {
	$('.api a').on('click',function(){
		$('.api a').removeClass('on');
		$(this).addClass('on');
	})
});
hljs.initHighlightingOnLoad();
