(function($) {
    $.fn.extend({
        slideTouch: function(options) {
            var defaults = {
                width: $(document).width(),
                height: $(document).height()
            }
            var set = $.extend({}, defaults, options);
            return this.each(function() {

                var pressX = 0,
                    pressY = 0;
                var that = $(this);
                var obj = $(this)[0];
                var t = 0;
                var slideIndex = 0;
                var slide = $(this).children('.slide');
                var total = slide.length;
                var slideDirection;
                var horizontal;
                var noslide;
                var navs = $('.slidenav li');
                that.width(set.width);
                that.height(set.height);
                slide.width(set.width);
                slide.height(set.height);
                slide.eq(0).addClass('on');

                if (set.direction == 'horizontal') {
                    horizontal = true;
                    $(this).addClass('horizontal');
                };
                if (set.nav) {
                    var li = '';
                    for (var i = 0; i < total; i++) {
                        li += '<li></li>'
                    }
                    var slideNav = '<ul class="slidenav">' + li + '</ul>';
                    $('.slidenav li:first').addClass('on');
                    that.after(slideNav);
                    //$('.slidenav li').eq(2).addClass('on');
                }
                document.addEventListener('touchmove', preventTouch, false);

                function preventTouch(e) {
                    e.preventDefault();
                };
                obj.addEventListener('touchstart', function(event) {
                    //event.preventDefault(); form表单提交等
                    event.stopPropagation();
                    if (event.targetTouches.length == 1) {
                        var touch = event.targetTouches[0];
                        t = Date.now();
                        pressX = touch.pageX;
                        pressY = touch.pageY;
                    };

                }, false);


                obj.addEventListener('touchmove', function(event) {
                    event.preventDefault();
                    event.stopPropagation();
                    if (event.targetTouches.length == 1) {
                        var touch = event.targetTouches[0];
                        var spanX = touch.pageX - pressX;
                        var spanY = touch.pageY - pressY;
                        if (Math.abs(spanX) > Math.abs(spanY)) {
                            if (spanX > 0) {
                                slideDirection = "right";
                            } else {
                                slideDirection = "left";
                            }
                        } else {
                            if (spanY > 0) {
                                slideDirection = "down";
                            } else {
                                slideDirection = "up";
                            }
                        }
                        //var a = slideDirection + "(" + spanX + ';' + spanY + ")";
                        //console.log(a);                  
                        if (horizontal) {
                            trans(obj, -set.width * slideIndex + spanX, 0);
                        } else {
                            trans(obj, 0, -set.height * slideIndex + spanY);
                        }
                        if (set.onMove != null) {
                            set.onMove();
                        };
                    }
                }, false);

                obj.addEventListener('touchend', function(event) {
                    event.stopPropagation();
                    if (event.changedTouches.length == 1) {
                        var touch = event.changedTouches[0];
                        var spanX = touch.pageX - pressX;
                        var spanY = Math.abs(touch.pageY - pressY);
                        t1 = Date.now() - t;
                        slideIndex = that.children('.slide.on').index();
                        if (horizontal) {
                            if (Math.abs(spanX) > 10 && t1 < 300 || spanX > set.height / 3) {
                                if (slideDirection == "left" && slideIndex < total - 1) {
                                    slideIndex++;
                                } else if (slideDirection == "right" && slideIndex > 0) {
                                    slideIndex--;
                                }
                            }
                            move(obj, -set.width * slideIndex, 0);
                        } else {
                            if (Math.abs(spanY) > 10 && t1 < 300 || spanY > set.height / 3) {
                                if (slideDirection == "up" && slideIndex < total - 1) {
                                    slideIndex++;
                                } else if (slideDirection == "down" && slideIndex > 0) {
                                    slideIndex--;
                                }
                            }
                            move(obj, 0, -set.height * slideIndex);
                        };
                        addE();
                        if (set.onEnd != null) {
                            set.onEnd();
                        };
                    }
                }, false);

                function move(obj, x, y) {
                    slide.eq(slideIndex).addClass('on').siblings().removeClass('on');

                    obj.style.webkitTransform = "translate3d(" + x + "px, " + y + "px, 0px)";
                    obj.style.webkitTransitionDuration = "300ms";
                    setTimeout(function() {
                        obj.style.webkitTransitionDuration = "0ms";
                    }, 500)
                }

                function trans(obj, x, y) {
                    obj.style.webkitTransform = "translate3d(" + x + "px, " + y + "px, 0px)";
                }

                $.fn.slideTouch.slideTo = function(obj, n) {
                    var obj = $(obj)[0];
                    var slide = $(obj).children('.slide');
                    move(obj, 0, -$(document).height() * n);
                    slideIndex = n;
                    slide.eq(n).addClass('on').siblings().removeClass('on');
                    if (set.onEnd != null) {
                        //set.onEnd();
                    };
                }
                $.fn.slideTouch.slideIndex = function() {
                    return slideIndex; //暂时获取不到，需要研究
                };
                $.fn.slideTouch.slideDirection = function() {
                    return slideDirection; //暂时获取不到，需要研究
                };
                if (set.onEnd != null) {
                    //set.onEnd();
                };


                function addE() {
                    $('.slide').each(function() {
                        var slide = $(this);
                        var noslide0 = slide.find('.noslide');
                        var box = slide.find('.noslide .box');
                        var noslide = slide.find('.noslide')[0];
                        if (!noslide) {
                            return;
                        };

                        noslide.addEventListener('touchstart', stop, false);
                        noslide.addEventListener('touchmove', stop, false);
                        noslide.addEventListener('touchend', noslide3);

                        var h1 = box.height() - noslide0.height();

                        function stop(e) {
                            e.stopPropagation();
                        }

                        function noslide3(e) {
                            e.stopPropagation();
                            var t = noslide.scrollTop;
                            if (Math.abs(t) <= 5 || Math.abs(t - h1) <= 5) {
                                noslide.removeEventListener('touchstart', stop, false);
                                noslide.removeEventListener('touchmove', stop);
                                noslide.removeEventListener('touchend', noslide3);
                            }
                        }
                    })
                };
                addE();
            });
        }
    });
})(jQuery);