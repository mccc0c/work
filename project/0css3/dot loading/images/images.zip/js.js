﻿$(function() {
	if (/Android|Windows Phone|webOS|iPhone|iPod|BlackBerry|iPad|Opera/i.test(navigator.userAgent)) {
		$('*').css('cursor', 'pointer');
	};
	setTimeout(function() {
		$('#loading').remove();
		$('.page0').addClass('on');
	}, 2000);
	var mySwiper = new Swiper('.swiper1', {
		direction: 'vertical',
		preventClicks: false,
		noSwiping: true,
		noSwipingClass: 'noswipe',
		onSlideChangeStart: function() {
			var a = mySwiper.activeIndex;
			if (a == 0) {
				$('.water').show('fast');
				$('.img2').fadeIn('fast');
				$('.img1').fadeIn();
				$('.img1 img').css('top','0');
			}
		}
	});
	//mySwiper.slideTo(1, 0, false);

	var mySwiper3 = new Swiper('.swiper3', {
		preventClicks: false,
		onSlideChangeStart: function() {
			var a = $('.swiper3 .swiper-slide.swiper-slide-active').index();
			move(a);
		}
	});
	mySwiper3.slideTo(1, 0, false);

	function move(a) {
		$('.casename li').eq(a).addClass('on').siblings().removeClass('on');
		if (a == 0) {
			$('.casename').animate({
				left: '37%'
			});
		}
		if (a == 1) {
			$('.casename').animate({
				left: '11%'
			});
		}
		if (a == 2) {
			$('.casename').animate({
				left: '-16%'
			});
		}
	}
	$(document).on('click', '.casename li', function() {
		var a = $(this).index();
		move(a);
		mySwiper3.slideTo(a, 0, false);
	})

	$(document).click(function() {
		$('.pop, .popbg').hide();
	});
	$(document).on('click', '.share2 img', function() {
		$('.pop, .popbg').show();
		return false;
	});
	$(document).on('click', '.close', function() {
		return false;
	});

	var w1 = $(document).width() * 0.7;
	$(".mbtn .img1 img").draggable({
		opacity: 0.8,
		start: function(event, ui) {
			$('.water').hide();
		},
		drag: function(event, ui) {
			ui.position.top = Math.min(50, ui.position.top);
			ui.position.top = Math.min(0, ui.position.top);
			ui.position.left = Math.max(0, ui.position.left);
			ui.position.left = Math.min(0, ui.position.left);
		},
		stop: function() {
			$(this).parent('.img1').fadeOut();
			$('.img2').fadeOut();
			setTimeout(function() {
				mySwiper.slideTo(1, 700, false);
			}, 300)
		}
	});
	$(".name li:eq(0)").draggable({
		opacity: 0.6,
		drag: function(event, ui) {
			ui.position.top = Math.min(120, ui.position.top);
			ui.position.top = Math.max(0, ui.position.top);
			ui.position.left = Math.max(0, ui.position.left);
			ui.position.left = Math.min(w1, ui.position.left);
		},
		start: function(event, ui) {
			$(this).addClass("on").siblings().removeClass('on').animate({
				'left': '0',
				'top': '0'
			});
			var i = $(this).index();
			$('.people li').hide().eq(i).show();
		}
	});
	$(".name li:eq(1)").draggable({
		opacity: 0.6,
		drag: function(event, ui) {
			ui.position.top = Math.min(120, ui.position.top);
			ui.position.top = Math.max(0, ui.position.top);
			ui.position.left = Math.max(-100, ui.position.left);
			ui.position.left = Math.min(150, ui.position.left);
		},
		start: function(event, ui) {
			$(this).addClass("on").siblings().removeClass('on').animate({
				'left': '0',
				'top': '0'
			});
			var i = $(this).index();
			$('.people li').hide().eq(i).show();
		}
	});
	$(".name li:eq(2)").draggable({
		opacity: 0.6,
		drag: function(event, ui) {
			ui.position.top = Math.min(120, ui.position.top);
			ui.position.top = Math.max(0, ui.position.top);
			ui.position.left = Math.max(-150, ui.position.left);
			ui.position.left = Math.min(100, ui.position.left);
		},
		start: function(event, ui) {
			$(this).addClass("on").siblings().removeClass('on').animate({
				'left': '0',
				'top': '0'
			});
			var i = $(this).index();
			$('.people li').hide().eq(i).show();
		}
	});
	$(".name li:eq(3)").draggable({
		opacity: 0.6,
		drag: function(event, ui) {
			ui.position.top = Math.min(120, ui.position.top);
			ui.position.top = Math.max(0, ui.position.top);
			ui.position.left = Math.max(-w1, ui.position.left);
			ui.position.left = Math.min(0, ui.position.left);
		},
		start: function(event, ui) {
			$(this).addClass("on").siblings().removeClass('on').animate({
				'left': '0',
				'top': '0'
			});
			var i = $(this).index();
			$('.people li').hide().eq(i).show();
		}
	});

	$(".box").droppable({
		drop: function(event, ui) {
			var index = $('.name li.on').index();
			$('.people li').hide().eq(index).show();
			console.log($('.light'));
			$('.light').addClass('on');
			setTimeout(function(){
				$('.light').removeClass('on');
			},2000)
		}
	});

	$(document).on('click', '.name li', function() {
		var i = $(this).index();
		$('.people li').eq(i).show().siblings().hide();
	});



});



window.shareData = {
	"imgUrl": "http://mat1.gtimg.com/sh/20150512_class/share.jpg",
	"imgWidth": 200,
	"imgHeight": 200,
	"link": window.location.href,
	"title": "互联网+连接智慧想象，这是您最需要的微信能量。",
	"content": "微信公开课上海站"
};

function onBridgeReady() {
	//隐藏底部工具条
	WeixinJSBridge.call('hideToolbar');

	//分享至好友
	WeixinJSBridge.on('menu:share:appmessage', function(argv) {
		WeixinJSBridge.invoke('sendAppMessage', {
			"img_url": window.shareData.imgUrl,
			"link": window.shareData.link,
			"desc": window.shareData.content,
			"title": window.shareData.title
		}, function(res) {})
	});

	//分享至朋友圈
	WeixinJSBridge.on('menu:share:timeline', function(argv) {
		WeixinJSBridge.invoke('shareTimeline', {
			"img_url": window.shareData.imgUrl,
			"img_width": window.shareData.imgWidth,
			"img_height": window.shareData.imgHeight,
			"link": window.shareData.link,
			"desc": window.shareData.content,
			"title": window.shareData.title
		}, function(res) {});
	});

	//分享至微博
	WeixinJSBridge.on('menu:share:weibo', function(argv) {
		WeixinJSBridge.invoke('shareWeibo', {
			"content": window.shareData.content,
			"url": window.shareData.link
		}, function(res) {});
	});

}

if (typeof WeixinJSBridge == "undefined") {
	if (document.addEventListener) {
		document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
	} else if (document.attachEvent) {
		document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
		document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
	}
} else {
	onBridgeReady();
}