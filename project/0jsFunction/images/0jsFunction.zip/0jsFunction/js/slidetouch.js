(function($) {
    $.fn.extend({
        slideTouch: function(options) {
            var defaults = {
                width: $(window).width(),
                height: $(window).height(),
                blur:false
            }
            var set = $.extend({}, defaults, options);
            var el=this;
            return this.each(function() {

                var pressX = 0,
                    pressY = 0;
                var $t = $(this);
                var obj = $(this)[0];
                var t = 0;
                var activeIndex = 0;
                var slide = $(this).children('.slide');
                var total = slide.length;
                var slideDirection;
                var horizontal;
                var noslide;
                var navs = $('.slidenav li');
                $t.width(set.width);
                $t.height(set.height);
                slide.width(set.width);
                slide.height(set.height);
                slide.eq(0).addClass('on');

                if (set.direction == 'horizontal') {
                    horizontal = true;
                    $(this).addClass('horizontal');
                };
                if (set.nav) {
                    var li = '';
                    for (var i = 0; i < total; i++) {
                        li += '<li></li>'
                    }
                    var slideNav = '<ul class="slidenav">' + li + '</ul>';
                    $('.slidenav li:first').addClass('on');
                    $t.after(slideNav);
                    //$('.slidenav li').eq(2).addClass('on');
                }
                document.addEventListener('touchmove', preventTouch, false);

                function preventTouch(e) {
                    e.preventDefault();
                };
                obj.addEventListener('touchstart', function(event) {
                    //event.preventDefault(); form表单提交等
                    event.stopPropagation();
                    if (event.targetTouches.length == 1) {
                        var touch = event.targetTouches[0];
                        t = Date.now();
                        pressX = touch.pageX;
                        pressY = touch.pageY;
                    };

                }, false);


                obj.addEventListener('touchmove', function(event) {
                    event.preventDefault();
                    event.stopPropagation();
                    if (event.targetTouches.length == 1) {
                        var touch = event.targetTouches[0];
                        var spanX = touch.pageX - pressX;
                        var spanY = touch.pageY - pressY;
                        if (Math.abs(spanX) > Math.abs(spanY)) {
                            if (spanX > 0) {
                                slideDirection = "right";
                            } else {
                                slideDirection = "left";
                            }
                        } else {
                            if (spanY > 0) {
                                slideDirection = "down";
                            } else {
                                slideDirection = "up";
                            }
                        }
                        //var a = slideDirection + "(" + spanX + ';' + spanY + ")";
                        //console.log(a);
                        if(set.blur){
                            $t.children('.slide.on').addClass('blur');
                        }
                        if (horizontal) {
                            trans(obj, -set.width * activeIndex + spanX, 0);
                        } else {                            
                            trans(obj, 0, -set.height * activeIndex + spanY);
                        }
                        if (set.onMove != null) {
                            set.onMove();
                        };
                    }
                }, false);

                obj.addEventListener('touchend', function(event) {
                    event.stopPropagation();
                    if (event.changedTouches.length == 1) {
                        var touch = event.changedTouches[0];
                        var spanX = touch.pageX - pressX;
                        var spanY = Math.abs(touch.pageY - pressY);
                        t1 = Date.now() - t;
                        activeIndex = $t.children('.slide.on').index();
                        $t.children('.slide.on').removeClass('blur');
                        if (horizontal) {
                            if (Math.abs(spanX) > 10 && t1 < 300 || spanX > set.height / 5) {
                                if (slideDirection == "left" && activeIndex < total - 1) {
                                    activeIndex++;
                                } else if (slideDirection == "right" && activeIndex > 0) {
                                    activeIndex--;
                                }
                            }                            
                            move(obj, -set.width * activeIndex, 0);
                        } else {
                            if (Math.abs(spanY) > 10 && t1 < 300 || spanY > set.height / 5) {
                                if (slideDirection == "up" && activeIndex < total - 1) {
                                    activeIndex++;
                                } else if (slideDirection == "down" && activeIndex > 0) {
                                    activeIndex--;
                                }
                            }
                            move(obj, 0, -set.height * activeIndex);
                        };
                        addE();
                        if (set.onEnd != null) {
                            set.onEnd();
                        };
                    }
                }, false);

                function move(obj, x, y) {
                    slide.eq(activeIndex).addClass('on').siblings().removeClass('on');
                    obj.style.webkitTransform = "translate3d(" + x + "px, " + y + "px, 0px)";
                    obj.style.webkitTransitionDuration = "300ms";
                    setTimeout(function() {
                        obj.style.webkitTransitionDuration = "0ms";
                    }, 500);                    
                }

                function trans(obj, x, y) {                    
                    obj.style.webkitTransform = "translate3d(" + x + "px, " + y + "px, 0px)";
                }
                el.slideTo = function(obj, n) {
                    var obj = $(obj)[0];
                    var slide = $(obj).children('.slide');
                    move(obj, 0, -$(document).height() * n);
                    activeIndex = n;
                    slide.eq(n).addClass('on').siblings().removeClass('on');
                    if (set.onEnd != null) {
                        //set.onEnd();
                    };
                }
                el.activeIndex = function() {
                    return activeIndex;
                };
                el.slideDirection = function() {
                    return slideDirection;
                };
                if (set.onEnd != null) {
                    //set.onEnd();
                };


                function addE() {
                    $('.slide').each(function() {
                        var slide = $(this);
                        var noslide0 = slide.find('.noslide');
                        var box = slide.find('.noslide .box');
                        var noslide = slide.find('.noslide')[0];
                        if (!noslide) {
                            return;
                        };

                        noslide.addEventListener('touchstart', stop, false);
                        noslide.addEventListener('touchmove', stop, false);
                        noslide.addEventListener('touchend', noslide3);

                        var h1 = box.height() - noslide0.height();

                        function stop(e) {
                            e.stopPropagation();
                        }

                        function noslide3(e) {
                            e.stopPropagation();
                            var t = noslide.scrollTop;
                            if (Math.abs(t) <= 5 || Math.abs(t - h1) <= 5) {
                                noslide.removeEventListener('touchstart', stop, false);
                                noslide.removeEventListener('touchmove', stop);
                                noslide.removeEventListener('touchend', noslide3);
                            }
                        }
                    })
                };
                addE();
            });
        }
    });
})(jQuery);